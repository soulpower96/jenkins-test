## Initial Public Release 0.2.0
### Summary

The first version released on GitHub and Puppet Forge


## Private Beta Release 0.1.0
### Summary

The initial private beta test given to customers.

#### Features

- Agent can be installed on Windows and Linux
- Agent Tag file is created
- Agent and EG services can be managed
